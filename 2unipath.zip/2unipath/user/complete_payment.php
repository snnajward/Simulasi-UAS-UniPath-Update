<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$id = $_GET['id'];

// Update status to reenrolled
$stmt = $pdo->prepare("UPDATE registrations SET status = 'reenrolled', registration_fee = 'paid', reenrolled_at = NOW() WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $_SESSION['user_id']]);

$_SESSION['message'] = 'Payment completed! Welcome to UNIPATH!';
header('Location: dashboard.php');
?>