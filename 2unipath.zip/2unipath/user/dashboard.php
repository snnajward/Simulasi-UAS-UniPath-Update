<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'user') {
    header('Location: ../login.php');
    exit();
}

// Get user's registration
$stmt = $pdo->prepare("SELECT * FROM registrations WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$_SESSION['user_id']]);
$registration = $stmt->fetch();

// Get announcements
$announcements = $pdo->query("SELECT * FROM announcements ORDER BY created_at DESC LIMIT 5")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - UNIPATH</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php"><i class="fas fa-graduation-cap"></i> UNIPATH</a>
            <div class="ms-auto">
                <span class="text-white me-3">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                <a href="../logout.php" class="btn btn-light btn-sm"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-tachometer-alt"></i> My Application Status</h5>
                    </div>
                    <div class="card-body">
                        <?php if(!$registration): ?>
                            <div class="alert alert-info">
                                <h5>Start Your Application</h5>
                                <p>You haven't submitted any application yet. Click the button below to begin.</p>
                                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#applicationModal">
                                    <i class="fas fa-file-alt"></i> New Application
                                </button>
                            </div>
                        <?php else: ?>
                            <div class="mb-4">
                                <h6>Registration Number: <strong><?php echo $registration['registration_number']; ?></strong></h6>
                                <div class="progress mb-3">
                                    <?php
                                    $statuses = ['pending' => 25, 'documents_reviewed' => 50, 'accepted' => 75, 'rejected' => 100, 'reenrolled' => 100];
                                    $progress = $statuses[$registration['status']] ?? 0;
                                    ?>
                                    <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: <?php echo $progress; ?>%"></div>
                                </div>
                                <div class="row">
                                    <div class="col-6 col-md-3 mb-2">
                                        <div class="status-badge <?php echo $registration['status'] == 'pending' ? 'active' : ($registration['status'] != 'pending' ? 'completed' : ''); ?>">
                                            <i class="fas fa-file-alt"></i> Registration
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-3 mb-2">
                                        <div class="status-badge <?php echo $registration['status'] == 'documents_reviewed' ? 'active' : ($registration['status'] != 'pending' ? 'completed' : ''); ?>">
                                            <i class="fas fa-search"></i> Review
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-3 mb-2">
                                        <div class="status-badge <?php echo in_array($registration['status'], ['accepted', 'reenrolled']) ? 'completed' : ($registration['status'] == 'rejected' ? 'rejected' : ''); ?>">
                                            <i class="fas fa-bullhorn"></i> Result
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-3 mb-2">
                                        <div class="status-badge <?php echo $registration['status'] == 'reenrolled' ? 'completed' : ''; ?>">
                                            <i class="fas fa-money-bill-wave"></i> Payment
                                        </div>
                                    </div>
                                </div>
                                <div class="alert alert-<?php echo $registration['status'] == 'accepted' ? 'success' : ($registration['status'] == 'rejected' ? 'danger' : 'info'); ?> mt-3">
                                    <strong>Status:</strong> 
                                    <?php
                                    $status_text = [
                                        'pending' => 'Pending Review',
                                        'documents_reviewed' => 'Documents Reviewed',
                                        'accepted' => 'Accepted!',
                                        'rejected' => 'Application Rejected',
                                        'reenrolled' => 'Enrollment Complete'
                                    ];
                                    echo $status_text[$registration['status']];
                                    ?>
                                </div>
                                <?php if($registration['status'] == 'accepted'): ?>
                                    <button class="btn btn-success" onclick="completePayment(<?php echo $registration['id']; ?>)">
                                        <i class="fas fa-money-bill-wave"></i> Complete Payment & Reenrollment
                                    </button>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card shadow mt-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-bullhorn"></i> Announcements</h5>
                    </div>
                    <div class="card-body">
                        <?php foreach($announcements as $ann): ?>
                            <div class="announcement-item">
                                <h6><?php echo htmlspecialchars($ann['title']); ?></h6>
                                <small class="text-muted"><?php echo date('F d, Y', strtotime($ann['created_at'])); ?></small>
                                <p class="mt-2"><?php echo nl2br(htmlspecialchars($ann['content'])); ?></p>
                                <hr>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0"><i class="fas fa-info-circle"></i> Quick Info</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <i class="fas fa-user text-primary"></i> <strong>Name:</strong> <?php echo $_SESSION['user_name']; ?>
                        </div>
                        <div class="mb-3">
                            <i class="fas fa-envelope text-primary"></i> <strong>Email:</strong> <?php echo $_SESSION['user_email']; ?>
                        </div>
                        <hr>
                        <div class="alert alert-warning">
                            <i class="fas fa-clock"></i> Registration deadline: December 31, 2025
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Application Modal -->
    <div class="modal fade" id="applicationModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">New Application Form</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="applicationForm" action="submit_application.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Full Name *</label>
                                <input type="text" name="full_name" class="form-control" value="<?php echo $_SESSION['user_name']; ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Email *</label>
                                <input type="email" name="email" class="form-control" value="<?php echo $_SESSION['user_email']; ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Phone *</label>
                                <input type="text" name="phone" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Birth Place</label>
                                <input type="text" name="birth_place" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Birth Date</label>
                                <input type="date" name="birth_date" class="form-control">
                            </div>
                            <div class="col-md-12 mb-3">
                                <label>Address</label>
                                <textarea name="address" class="form-control" rows="2"></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>High School</label>
                                <input type="text" name="high_school" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Graduation Year</label>
                                <input type="number" name="graduation_year" class="form-control">
                            </div>
                            <div class="col-md-12 mb-3">
                                <label>Desired Program</label>
                                <select name="desired_program" class="form-control" required>
                                    <option value="">Select Program</option>
                                    <option>Computer Science</option>
                                    <option>Business Administration</option>
                                    <option>Engineering</option>
                                    <option>Medicine</option>
                                    <option>Law</option>
                                </select>
                            </div>
                            <div class="col-md-12 mb-3">
                                <label>Upload Documents (PDF/Image)</label>
                                <input type="file" name="documents[]" class="form-control" multiple accept=".pdf,.jpg,.jpeg,.png" required>
                                <small class="text-muted">Upload: ID Card, Diploma, Transcript</small>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit Application</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function completePayment(regId) {
        if(confirm('Confirm payment of Rp 500,000 for reenrollment?')) {
            window.location.href = 'complete_payment.php?id=' + regId;
        }
    }
    </script>
</body>
</html>