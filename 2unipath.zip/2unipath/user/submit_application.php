<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Generate registration number
    $reg_number = 'UNP' . date('Ymd') . rand(1000, 9999);
    
    // Insert registration
    $stmt = $pdo->prepare("INSERT INTO registrations (user_id, registration_number, full_name, email, phone, birth_place, birth_date, address, high_school, graduation_year, desired_program, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
    
    $stmt->execute([
        $_SESSION['user_id'],
        $reg_number,
        $_POST['full_name'],
        $_POST['email'],
        $_POST['phone'],
        $_POST['birth_place'],
        $_POST['birth_date'],
        $_POST['address'],
        $_POST['high_school'],
        $_POST['graduation_year'],
        $_POST['desired_program']
    ]);
    
    $registration_id = $pdo->lastInsertId();
    
    // Handle file uploads
    $upload_dir = '../uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    foreach($_FILES['documents']['tmp_name'] as $key => $tmp_name) {
        $file_name = time() . '_' . $_FILES['documents']['name'][$key];
        $file_path = $upload_dir . $file_name;
        
        if(move_uploaded_file($tmp_name, $file_path)) {
            $stmt = $pdo->prepare("INSERT INTO documents (registration_id, document_type, file_path) VALUES (?, ?, ?)");
            $stmt->execute([$registration_id, 'Document ' . ($key+1), $file_path]);
        }
    }
    
    $_SESSION['message'] = 'Application submitted successfully!';
    header('Location: dashboard.php');
}
?>