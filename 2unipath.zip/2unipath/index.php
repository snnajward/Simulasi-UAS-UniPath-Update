<?php
require_once 'config/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UNIPATH - University Admission Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-graduation-cap me-2"></i>
                UNIPATH
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#process">Process</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About</a>
                    </li>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="user/dashboard.php"><i class="fas fa-tachometer-alt"></i> My Dashboard</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                            </ul>
                        </li>
                    <?php elseif(isset($_SESSION['admin_id'])): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user-shield"></i> <?php echo htmlspecialchars($_SESSION['admin_name']); ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="admin/dashboard.php"><i class="fas fa-tachometer-alt"></i> Admin Panel</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="btn btn-primary btn-sm ms-2" href="user_login.php">Student Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-outline-primary btn-sm ms-2" href="admin_login.php">Admin Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-outline-light btn-sm ms-2" href="register.php">Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container">
            <div class="row align-items-center min-vh-100">
                <div class="col-lg-6 text-white">
                    <h1 class="display-4 fw-bold mb-4 animate-text">Your Path to <span class="text-warning">Higher Education</span></h1>
                    <p class="lead mb-4">Join UNIPATH and take the first step towards your dream university. Simple, transparent, and efficient admission process.</p>
                    <?php if(!isset($_SESSION['user_id']) && !isset($_SESSION['admin_id'])): ?>
                        <a href="user_login.php" class="btn btn-primary btn-lg me-3">Student Login</a>
                        <a href="admin_login.php" class="btn btn-outline-light btn-lg">Admin Login</a>
                    <?php else: ?>
                        <a href="<?php echo isset($_SESSION['admin_id']) ? 'admin/dashboard.php' : 'user/dashboard.php'; ?>" class="btn btn-primary btn-lg">Go to Dashboard</a>
                    <?php endif; ?>
                </div>
                <div class="col-lg-6 text-center animate-float">
                    <i class="fas fa-university fa-8x text-white opacity-75"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Process Section -->
    <div id="process" class="process-section py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Admission Process</h2>
                <p class="text-muted">Follow these simple steps to complete your admission</p>
            </div>
            <div class="row g-4">
                <div class="col-md-4 animate-on-scroll">
                    <div class="process-card text-center p-4">
                        <div class="process-icon">
                            <i class="fas fa-file-alt"></i>
                            <div class="step-number">1</div>
                        </div>
                        <h4 class="mt-3">Online Registration</h4>
                        <p class="text-muted">Fill out application form and upload required documents</p>
                        <div class="process-status">Pendaftaran Online</div>
                    </div>
                </div>
                <div class="col-md-4 animate-on-scroll">
                    <div class="process-card text-center p-4">
                        <div class="process-icon">
                            <i class="fas fa-search"></i>
                            <div class="step-number">2</div>
                        </div>
                        <h4 class="mt-3">Document Review</h4>
                        <p class="text-muted">University team checks criteria & reviews applications</p>
                        <div class="process-status">Seleksi Berkas</div>
                    </div>
                </div>
                <div class="col-md-4 animate-on-scroll">
                    <div class="process-card text-center p-4">
                        <div class="process-icon">
                            <i class="fas fa-bullhorn"></i>
                            <div class="step-number">3</div>
                        </div>
                        <h4 class="mt-3">Results Announcement</h4>
                        <p class="text-muted">Decision made and students notified</p>
                        <div class="process-status">Pengumuman Hasil</div>
                    </div>
                </div>
                <div class="col-md-6 mx-auto mt-4 animate-on-scroll">
                    <div class="process-card text-center p-4">
                        <div class="process-icon">
                            <i class="fas fa-money-bill-wave"></i>
                            <div class="step-number">4</div>
                        </div>
                        <h4 class="mt-3">Reenrollment & Payment</h4>
                        <p class="text-muted">Complete payment and confirm enrollment</p>
                        <div class="process-status">Daftar Ulang</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- About Section -->
    <div id="about" class="about-section py-5 bg-light">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4">
                   <!-- Ganti dengan gambar real -->
<img src="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600" alt="Welcome" class="img-fluid rounded shadow">
                </div>
                <div class="col-lg-6">
                    <h2 class="section-title mb-4">Welcome New Students!</h2>
                    <h4 class="text-muted mb-3">Semat Datang Mahasiswa Baru</h4>
                    <p class="lead">Introduction to campus life and community</p>
                    <p>Join our vibrant community of learners and leaders. At UNIPATH, we're committed to your success and growth throughout your academic journey.</p>
                    <div class="mt-4">
                        <div class="row">
                            <div class="col-6 mb-3">
                                <i class="fas fa-users text-primary me-2"></i> 5000+ Students
                            </div>
                            <div class="col-6 mb-3">
                                <i class="fas fa-chalkboard-teacher text-primary me-2"></i> 200+ Faculty
                            </div>
                            <div class="col-6 mb-3">
                                <i class="fas fa-globe text-primary me-2"></i> 30+ Programs
                            </div>
                            <div class="col-6 mb-3">
                                <i class="fas fa-trophy text-primary me-2"></i> 100+ Awards
                            </div>
                        </div>
                    </div>
                    <div class="mt-4">
                        <a href="register.php" class="btn btn-primary">Apply Now <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Testimonials Section -->
    <div class="testimonials-section py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">What Our Students Say</h2>
                <p class="text-muted">Success stories from our alumni</p>
            </div>
            <div class="row g-4">
                <div class="col-md-4 animate-on-scroll">
                    <div class="testimonial-card p-4 shadow-sm">
                        <i class="fas fa-quote-left fa-2x text-primary mb-3"></i>
                        <p class="mb-3">"UNIPATH made my university admission process so easy and transparent. I'm now pursuing my dream degree!"</p>
                        <div class="d-flex align-items-center">
                            <i class="fas fa-user-circle fa-2x text-primary me-2"></i>
                            <div>
                                <h6 class="mb-0">John Doe</h6>
                                <small class="text-muted">Computer Science 2024</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 animate-on-scroll">
                    <div class="testimonial-card p-4 shadow-sm">
                        <i class="fas fa-quote-left fa-2x text-primary mb-3"></i>
                        <p class="mb-3">"The staff was very helpful throughout the process. Highly recommended for aspiring students!"</p>
                        <div class="d-flex align-items-center">
                            <i class="fas fa-user-circle fa-2x text-primary me-2"></i>
                            <div>
                                <h6 class="mb-0">Sarah Smith</h6>
                                <small class="text-muted">Business 2024</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 animate-on-scroll">
                    <div class="testimonial-card p-4 shadow-sm">
                        <i class="fas fa-quote-left fa-2x text-primary mb-3"></i>
                        <p class="mb-3">"Quick response and efficient system. I got my acceptance letter within a week!"</p>
                        <div class="d-flex align-items-center">
                            <i class="fas fa-user-circle fa-2x text-primary me-2"></i>
                            <div>
                                <h6 class="mb-0">Mike Johnson</h6>
                                <small class="text-muted">Engineering 2024</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- FAQ Section -->
    <div class="faq-section py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Frequently Asked Questions</h2>
                <p class="text-muted">Got questions? We've got answers</p>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="accordion" id="faqAccordion">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                    How long does the admission process take?
                                </button>
                            </h2>
                            <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    The complete admission process typically takes 2-3 weeks from application submission to final decision.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                    What documents are required for registration?
                                </button>
                            </h2>
                            <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Required documents: High school diploma, transcript, ID card, and passport photo.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                    Is there an application fee?
                                </button>
                            </h2>
                            <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Yes, the application fee is Rp 500,000 and is payable upon reenrollment.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                                    Can I apply for multiple programs?
                                </button>
                            </h2>
                            <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Yes, you can apply for up to 3 programs with a single application.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5><i class="fas fa-graduation-cap"></i> UNIPATH</h5>
                    <p>Your trusted partner in university admission process since 2020.</p>
                    <div class="social-links">
                        <a href="#" class="text-white me-2"><i class="fab fa-facebook fa-lg"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin fa-lg"></i></a>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#process">Admission Process</a></li>
                        <li><a href="#about">About Us</a></li>
                        <li><a href="user_login.php">Student Login</a></li>
                        <li><a href="admin_login.php">Admin Login</a></li>
                        <li><a href="register.php">Register</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>Contact Info</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt"></i> Jakarta, Indonesia</li>
                        <li><i class="fas fa-envelope"></i> info@unipath.com</li>
                        <li><i class="fas fa-phone"></i> +62 812-3456-7890</li>
                        <li><i class="fas fa-clock"></i> Mon-Fri: 8AM - 5PM</li>
                    </ul>
                </div>
            </div>
            <hr class="bg-light">
            <div class="text-center">
                <p class="mb-0">&copy; 2025 UNIPATH. All rights reserved. | Designed for better education</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
    
    <script>
        // Smooth scroll for navigation
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    </script>
</body>
</html>