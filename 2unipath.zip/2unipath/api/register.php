<?php

include '../config/koneksi.php';

$fullname = htmlspecialchars($_POST['fullname']);
$email    = htmlspecialchars($_POST['email']);
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

/*
|--------------------------------------------------------------------------
| CHECK EMAIL
|--------------------------------------------------------------------------
*/

$check = mysqli_query($conn,
"SELECT * FROM users WHERE email='$email'");

if(mysqli_num_rows($check) > 0){

    echo "
    <script>
        alert('Email sudah digunakan');
        window.location='../register.php';
    </script>
    ";

    exit;
}

/*
|--------------------------------------------------------------------------
| INSERT USER
|--------------------------------------------------------------------------
*/

$query = mysqli_query($conn,
"INSERT INTO users(fullname,email,password)
VALUES('$fullname','$email','$password')");

if($query){

    echo "
    <script>
        alert('Register berhasil');
        window.location='../login.php';
    </script>
    ";

}else{

    echo "
    <script>
        alert('Register gagal');
        window.location='../register.php';
    </script>
    ";

}
?>