<?php

session_start();

include '../config/koneksi.php';

$email    = $_POST['email'];
$password = $_POST['password'];

$query = mysqli_query($conn,
"SELECT * FROM users WHERE email='$email'");

$user = mysqli_fetch_assoc($query);

if($user){

    if(password_verify($password, $user['password'])){

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['role'] = $user['role'];

        /*
        |--------------------------------------------------------------------------
        | REDIRECT
        |--------------------------------------------------------------------------
        */

        if($user['role'] == 'admin'){

            header("Location: ../admin/dashboard.php");

        }else{

            header("Location: ../user/dashboard.php");

        }

    }else{

        echo "
        <script>
            alert('Password salah');
            window.location='../login.php';
        </script>
        ";

    }

}else{

    echo "
    <script>
        alert('Email tidak ditemukan');
        window.location='../login.php';
    </script>
    ";

}
?>