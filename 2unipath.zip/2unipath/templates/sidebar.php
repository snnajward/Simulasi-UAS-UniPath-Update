<div class="sidebar">

    <!-- Logo -->
    <div class="sidebar-logo">

        <h3>
            UniPath
        </h3>

    </div>

    <!-- Menu -->
    <ul class="sidebar-menu">

        <li>
            <a href="dashboard.php">

                <i class="bi bi-grid-fill"></i>

                Dashboard

            </a>
        </li>

        <li>
            <a href="profile.php">

                <i class="bi bi-person-fill"></i>

                Profile

            </a>
        </li>

        <li>
            <a href="upload.php">

                <i class="bi bi-cloud-upload-fill"></i>

                Upload Dokumen

            </a>
        </li>

        <li>
            <a href="result.php">

                <i class="bi bi-megaphone-fill"></i>

                Pengumuman

            </a>
        </li>

        <li>
            <a href="payment.php">

                <i class="bi bi-credit-card-fill"></i>

                Pembayaran

            </a>
        </li>

        <li>
            <a href="ospek.php">

                <i class="bi bi-mortarboard-fill"></i>

                OSPK

            </a>
        </li>

        <li>
            <a href="../logout.php"
            class="logout-btn">

                <i class="bi bi-box-arrow-right"></i>

                Logout

            </a>
        </li>

    </ul>

</div>