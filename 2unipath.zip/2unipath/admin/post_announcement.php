<?php
require_once '../config/database.php';

// Cek login admin
if (!isset($_SESSION['admin_id']) || $_SESSION['admin_role'] != 'admin') {
    header('Location: ../admin_login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $created_by = $_SESSION['admin_id'];
    
    $stmt = $pdo->prepare("INSERT INTO announcements (title, content, created_by) VALUES (?, ?, ?)");
    
    if ($stmt->execute([$title, $content, $created_by])) {
        $_SESSION['success_message'] = 'Announcement posted successfully!';
    } else {
        $_SESSION['error_message'] = 'Failed to post announcement!';
    }
    
    header('Location: dashboard.php');
    exit();
}
?>