<?php
require_once '../config/database.php';

// Cek login admin - gunakan session yang benar
if (!isset($_SESSION['admin_id']) || $_SESSION['admin_role'] != 'admin') {
    header('Location: ../admin_login.php');
    exit();
}

// Get statistics
$total_applications = $pdo->query("SELECT COUNT(*) FROM registrations")->fetchColumn();
$pending_reviews = $pdo->query("SELECT COUNT(*) FROM registrations WHERE status = 'pending'")->fetchColumn();
$documents_reviewed = $pdo->query("SELECT COUNT(*) FROM registrations WHERE status = 'documents_reviewed'")->fetchColumn();
$accepted = $pdo->query("SELECT COUNT(*) FROM registrations WHERE status = 'accepted'")->fetchColumn();
$reenrolled = $pdo->query("SELECT COUNT(*) FROM registrations WHERE status = 'reenrolled'")->fetchColumn();

// Get all registrations
$registrations = $pdo->query("SELECT r.*, u.full_name as user_name FROM registrations r JOIN users u ON r.user_id = u.id ORDER BY r.submitted_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - UNIPATH</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: #f8f9fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .admin-sidebar {
            background: linear-gradient(180deg, #2c3e50 0%, #1a252f 100%);
            min-height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            z-index: 100;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        
        .stat-card {
            transition: transform 0.3s ease;
            cursor: pointer;
            border-radius: 10px;
            border: none;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .bg-gradient-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .bg-gradient-success {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        }
        
        .bg-gradient-warning {
            background: linear-gradient(135deg, #f6c23e 0%, #f4b619 100%);
        }
        
        .bg-gradient-info {
            background: linear-gradient(135deg, #36b9cc 0%, #258391 100%);
        }
        
        .bg-gradient-danger {
            background: linear-gradient(135deg, #e74a3b 0%, #c0392b 100%);
        }
        
        .nav-link {
            color: #ecf0f1;
            padding: 12px 20px;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .nav-link.active {
            background: rgba(255,255,255,0.2);
            border-left: 4px solid #e74c3c;
        }
        
        .table-actions {
            white-space: nowrap;
        }
        
        .table-actions button {
            margin: 2px;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: bold;
        }
        
        @media (max-width: 768px) {
            .admin-sidebar {
                width: 100%;
                position: relative;
                min-height: auto;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="admin-sidebar">
        <div class="text-center py-4">
            <i class="fas fa-graduation-cap fa-3x text-white"></i>
            <h5 class="text-white mt-2">UNIPATH Admin</h5>
            <small class="text-white-50"><?php echo htmlspecialchars($_SESSION['admin_name']); ?></small>
        </div>
        <nav class="nav flex-column">
            <a class="nav-link active" href="dashboard.php">
                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
            </a>
            <a class="nav-link" href="#applications">
                <i class="fas fa-users me-2"></i> Applications
            </a>
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#announcementModal">
                <i class="fas fa-bullhorn me-2"></i> Announcements
            </a>
            <hr class="bg-secondary">
            <a class="nav-link" href="../logout.php">
                <i class="fas fa-sign-out-alt me-2"></i> Logout
            </a>
        </nav>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?>!</h2>
            <div>
                <span class="badge bg-primary">Admin Panel</span>
            </div>
        </div>
        
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card stat-card bg-gradient-primary text-white shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1">Total Applications</h6>
                                <h2 class="mb-0"><?php echo $total_applications; ?></h2>
                            </div>
                            <i class="fas fa-file-alt fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stat-card bg-gradient-warning text-white shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1">Pending Review</h6>
                                <h2 class="mb-0"><?php echo $pending_reviews; ?></h2>
                            </div>
                            <i class="fas fa-clock fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stat-card bg-gradient-info text-white shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1">Documents Reviewed</h6>
                                <h2 class="mb-0"><?php echo $documents_reviewed; ?></h2>
                            </div>
                            <i class="fas fa-search fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stat-card bg-gradient-success text-white shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1">Accepted</h6>
                                <h2 class="mb-0"><?php echo $accepted; ?></h2>
                            </div>
                            <i class="fas fa-check-circle fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Applications Table -->
        <div class="card shadow" id="applications">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0"><i class="fas fa-users me-2"></i> Student Applications</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Reg Number</th>
                                <th>Student Name</th>
                                <th>Program</th>
                                <th>Submitted</th>
                                <th>Status</th>
                                <th width="250">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            foreach($registrations as $reg): 
                            ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo htmlspecialchars($reg['registration_number']); ?></td>
                                <td><?php echo htmlspecialchars($reg['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($reg['desired_program']); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($reg['submitted_at'])); ?></td>
                                <td>
                                    <?php
                                    $status_class = '';
                                    $status_text = '';
                                    switch($reg['status']) {
                                        case 'pending':
                                            $status_class = 'warning';
                                            $status_text = 'PENDING';
                                            break;
                                        case 'documents_reviewed':
                                            $status_class = 'info';
                                            $status_text = 'DOCUMENTS REVIEWED';
                                            break;
                                        case 'accepted':
                                            $status_class = 'success';
                                            $status_text = 'ACCEPTED';
                                            break;
                                        case 'rejected':
                                            $status_class = 'danger';
                                            $status_text = 'REJECTED';
                                            break;
                                        case 'reenrolled':
                                            $status_class = 'primary';
                                            $status_text = 'REENROLLED';
                                            break;
                                        default:
                                            $status_class = 'secondary';
                                            $status_text = strtoupper($reg['status']);
                                    }
                                    ?>
                                    <span class="badge bg-<?php echo $status_class; ?>"><?php echo $status_text; ?></span>
                                </td>
                                <td class="table-actions">
                                    <button class="btn btn-sm btn-info" onclick="viewApplication(<?php echo $reg['id']; ?>)">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                    
                                    <?php if($reg['status'] == 'pending'): ?>
                                        <button class="btn btn-sm btn-warning" onclick="updateStatus(<?php echo $reg['id']; ?>, 'documents_reviewed')">
                                            <i class="fas fa-search"></i> Review Documents
                                        </button>
                                    <?php endif; ?>
                                    
                                    <?php if($reg['status'] == 'documents_reviewed'): ?>
                                        <button class="btn btn-sm btn-success" onclick="updateStatus(<?php echo $reg['id']; ?>, 'accepted')">
                                            <i class="fas fa-check-circle"></i> Accept
                                        </button>
                                        <button class="btn btn-sm btn-danger" onclick="updateStatus(<?php echo $reg['id']; ?>, 'rejected')">
                                            <i class="fas fa-times-circle"></i> Reject
                                        </button>
                                    <?php endif; ?>
                                    
                                    <?php if($reg['status'] == 'accepted'): ?>
                                        <button class="btn btn-sm btn-primary" onclick="updateStatus(<?php echo $reg['id']; ?>, 'reenrolled')">
                                            <i class="fas fa-money-bill-wave"></i> Confirm Reenrollment
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            
                            <?php if(count($registrations) == 0): ?>
                            <tr>
                                <td colspan="7" class="text-center">No applications found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- View Application Modal -->
    <div class="modal fade" id="viewModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">
                        <i class="fas fa-file-alt me-2"></i> Application Details
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="applicationDetails">
                    <div class="text-center py-4">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-2">Loading application details...</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Announcement Modal -->
    <div class="modal fade" id="announcementModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">
                        <i class="fas fa-bullhorn me-2"></i> Post New Announcement
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form action="post_announcement.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Title *</label>
                            <input type="text" name="title" class="form-control" required placeholder="Enter announcement title">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Content *</label>
                            <textarea name="content" class="form-control" rows="5" required placeholder="Enter announcement content..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane me-1"></i> Post Announcement
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function viewApplication(id) {
        // Show loading
        document.getElementById('applicationDetails').innerHTML = `
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Loading application details...</p>
            </div>
        `;
        
        // Fetch application details
        fetch(`view_application.php?id=${id}`)
            .then(response => response.text())
            .then(data => {
                document.getElementById('applicationDetails').innerHTML = data;
                // Show modal
                const modal = new bootstrap.Modal(document.getElementById('viewModal'));
                modal.show();
            })
            .catch(error => {
                document.getElementById('applicationDetails').innerHTML = `
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> Error loading application details: ${error}
                    </div>
                `;
            });
    }
    
    function updateStatus(id, status) {
        let message = '';
        switch(status) {
            case 'documents_reviewed':
                message = 'Mark documents as reviewed?';
                break;
            case 'accepted':
                message = 'Accept this application? Student will be notified.';
                break;
            case 'rejected':
                message = 'Reject this application? This action cannot be undone.';
                break;
            case 'reenrolled':
                message = 'Confirm reenrollment and payment?';
                break;
            default:
                message = 'Update application status?';
        }
        
        if(confirm(message)) {
            window.location.href = `update_status.php?id=${id}&status=${status}`;
        }
    }
    
    // Auto refresh untuk menampilkan pesan sukses/error
    <?php if(isset($_SESSION['success_message'])): ?>
        setTimeout(() => {
            alert('<?php echo $_SESSION['success_message']; ?>');
        }, 100);
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>
    
    <?php if(isset($_SESSION['error_message'])): ?>
        setTimeout(() => {
            alert('Error: <?php echo $_SESSION['error_message']; ?>');
        }, 100);
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>
    </script>
</body>
</html>