<?php
require_once 'config/database.php';

// Hapus admin yang ada (opsional)
$pdo->exec("DELETE FROM users WHERE email = 'admin@unipath.com'");

// Buat admin baru dengan password yang benar
$full_name = 'Administrator';
$email = 'admin@unipath.com';
$password = password_hash('admin123', PASSWORD_DEFAULT);
$phone = '081234567890';
$role = 'admin';

$sql = "INSERT INTO users (full_name, email, password, phone, role) VALUES (?, ?, ?, ?, ?)";
$stmt = $pdo->prepare($sql);

if ($stmt->execute([$full_name, $email, $password, $phone, $role])) {
    echo "✅ Admin berhasil dibuat!<br>";
    echo "Email: admin@unipath.com<br>";
    echo "Password: admin123<br>";
    echo "<br>Hash password: " . $password;
} else {
    echo "❌ Gagal membuat admin!";
}

// Test login
echo "<br><br>Test login:<br>";
$test_stmt = $pdo->prepare("SELECT * FROM users WHERE email = 'admin@unipath.com'");
$test_stmt->execute();
$user = $test_stmt->fetch();

if ($user && password_verify('admin123', $user['password'])) {
    echo "✅ Login test SUCCESS!";
} else {
    echo "❌ Login test FAILED!";
}
?>