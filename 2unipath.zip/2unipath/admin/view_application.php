<?php
require_once '../config/database.php';

// Cek login admin
if (!isset($_SESSION['admin_id']) || $_SESSION['admin_role'] != 'admin') {
    echo '<div class="alert alert-danger">Unauthorized access</div>';
    exit();
}

$id = isset($_GET['id']) ? $_GET['id'] : 0;

$stmt = $pdo->prepare("SELECT r.*, u.email as user_email, u.phone as user_phone 
                       FROM registrations r 
                       JOIN users u ON r.user_id = u.id 
                       WHERE r.id = ?");
$stmt->execute([$id]);
$app = $stmt->fetch();

if (!$app) {
    echo '<div class="alert alert-warning">Application not found</div>';
    exit();
}

// Get documents
$docs = $pdo->prepare("SELECT * FROM documents WHERE registration_id = ?");
$docs->execute([$id]);
$documents = $docs->fetchAll();
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <h6 class="text-primary mb-3"><i class="fas fa-user"></i> Personal Information</h6>
            <table class="table table-sm table-bordered">
                <tr>
                    <th width="35%">Full Name</th>
                    <td><?php echo htmlspecialchars($app['full_name']); ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo htmlspecialchars($app['email']); ?></td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td><?php echo htmlspecialchars($app['phone']); ?></td>
                </tr>
                <tr>
                    <th>Birth Place/Date</th>
                    <td><?php echo htmlspecialchars($app['birth_place'] . ' / ' . $app['birth_date']); ?></td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td><?php echo nl2br(htmlspecialchars($app['address'])); ?></td>
                </tr>
            </table>
        </div>
        <div class="col-md-6">
            <h6 class="text-primary mb-3"><i class="fas fa-graduation-cap"></i> Education Information</h6>
            <table class="table table-sm table-bordered">
                <tr>
                    <th width="35%">High School</th>
                    <td><?php echo htmlspecialchars($app['high_school']); ?></td>
                </tr>
                <tr>
                    <th>Graduation Year</th>
                    <td><?php echo htmlspecialchars($app['graduation_year']); ?></td>
                </tr>
                <tr>
                    <th>Desired Program</th>
                    <td><?php echo htmlspecialchars($app['desired_program']); ?></td>
                </tr>
                <tr>
                    <th>Registration Number</th>
                    <td><strong><?php echo htmlspecialchars($app['registration_number']); ?></strong></td>
                </tr>
                <tr>
                    <th>Submitted Date</th>
                    <td><?php echo date('d F Y H:i', strtotime($app['submitted_at'])); ?></td>
                </tr>
            </table>
        </div>
    </div>
    
    <div class="mt-3">
        <h6 class="text-primary mb-3"><i class="fas fa-file-alt"></i> Uploaded Documents</h6>
        <div class="list-group">
            <?php if(count($documents) > 0): ?>
                <?php foreach($documents as $doc): ?>
                    <a href="../<?php echo $doc['file_path']; ?>" target="_blank" class="list-group-item list-group-item-action">
                        <i class="fas fa-file-pdf text-danger"></i> 
                        <?php echo htmlspecialchars(basename($doc['file_path'])); ?>
                        <small class="text-muted">(Uploaded: <?php echo date('d/m/Y', strtotime($doc['uploaded_at'])); ?>)</small>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="alert alert-info">No documents uploaded</div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="mt-3">
        <h6 class="text-primary mb-3"><i class="fas fa-info-circle"></i> Application Status</h6>
        <div class="alert alert-<?php 
            echo $app['status'] == 'accepted' ? 'success' : 
                 ($app['status'] == 'rejected' ? 'danger' : 
                 ($app['status'] == 'pending' ? 'warning' : 'info')); 
        ?>">
            <strong>Current Status:</strong> <?php echo strtoupper(str_replace('_', ' ', $app['status'])); ?>
        </div>
    </div>
</div>