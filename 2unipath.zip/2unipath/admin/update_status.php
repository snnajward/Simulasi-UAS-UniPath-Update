<?php
require_once '../config/database.php';

// Cek login admin
if (!isset($_SESSION['admin_id']) || $_SESSION['admin_role'] != 'admin') {
    $_SESSION['error_message'] = 'Unauthorized access';
    header('Location: dashboard.php');
    exit();
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$status = isset($_GET['status']) ? $_GET['status'] : '';

// Validasi status yang diperbolehkan
$allowed_status = ['pending', 'documents_reviewed', 'accepted', 'rejected', 'reenrolled'];
if (!in_array($status, $allowed_status)) {
    $_SESSION['error_message'] = 'Invalid status value';
    header('Location: dashboard.php');
    exit();
}

if ($id <= 0) {
    $_SESSION['error_message'] = 'Invalid application ID';
    header('Location: dashboard.php');
    exit();
}

try {
    // Mulai transaction
    $pdo->beginTransaction();
    
    // Update status
    $stmt = $pdo->prepare("UPDATE registrations SET status = ?, reviewed_at = NOW() WHERE id = ?");
    $stmt->execute([$status, $id]);
    
    // Jika status accepted, tambahkan waktu accepted
    if ($status == 'accepted') {
        $stmt2 = $pdo->prepare("UPDATE registrations SET accepted_at = NOW() WHERE id = ?");
        $stmt2->execute([$id]);
        $_SESSION['success_message'] = 'Application accepted successfully! Student has been notified.';
    }
    
    // Jika status rejected
    elseif ($status == 'rejected') {
        $_SESSION['success_message'] = 'Application rejected.';
    }
    
    // Jika status documents_reviewed
    elseif ($status == 'documents_reviewed') {
        $_SESSION['success_message'] = 'Documents reviewed. Ready for decision.';
    }
    
    // Jika status reenrolled
    elseif ($status == 'reenrolled') {
        $stmt3 = $pdo->prepare("UPDATE registrations SET registration_fee = 'paid', reenrolled_at = NOW() WHERE id = ?");
        $stmt3->execute([$id]);
        $_SESSION['success_message'] = 'Reenrollment confirmed! Student has been registered.';
    }
    
    // Commit transaction
    $pdo->commit();
    
} catch(PDOException $e) {
    // Rollback jika ada error
    $pdo->rollBack();
    $_SESSION['error_message'] = 'Database error: ' . $e->getMessage();
}

// Redirect back to dashboard
header('Location: dashboard.php#applications');
exit();
?>